CREATE TABLE source_table (
  `timestamp` TIMESTAMP(3),
  `sensor_id` VARCHAR(50),
  `temperature` DOUBLE,
  `humidity` DOUBLE,
  `location` VARCHAR(100),
  WATERMARK FOR `timestamp` AS `timestamp` - INTERVAL '5' SECOND
) WITH (
  'connector' = 'kinesis',
  'stream' = 'cloudpulse-stream-dev-1ad3a61b',
  'aws.region' = 'us-east-1',
  'format' = 'json'
);

CREATE TABLE sink_table (
  `window_start` TIMESTAMP(3),
  `window_end` TIMESTAMP(3),
  `sensor_id` VARCHAR(50),
  `avg_temperature` DOUBLE,
  `avg_humidity` DOUBLE,
  `record_count` BIGINT
) WITH (
  'connector' = 'kinesis',
  'stream' = 'cloudpulse-stream-dev-1ad3a61b-aggregated',
  'aws.region' = 'us-east-1',
  'format' = 'json'
);

INSERT INTO sink_table
SELECT 
  TUMBLE_START(`timestamp`, INTERVAL '1' MINUTE) as window_start,
  TUMBLE_END(`timestamp`, INTERVAL '1' MINUTE) as window_end,
  sensor_id,
  AVG(temperature) as avg_temperature,
  AVG(humidity) as avg_humidity,
  COUNT(*) as record_count
FROM source_table
GROUP BY 
  sensor_id,
  TUMBLE(`timestamp`, INTERVAL '1' MINUTE);
